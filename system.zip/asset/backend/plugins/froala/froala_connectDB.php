<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_pj";
?>
