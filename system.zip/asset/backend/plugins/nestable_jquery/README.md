# simple-management-menu-php-mysql-jquery
Simple Management Menu Using PHP, MySQL, JQuery
Modify from  ([https://github.com/dbushell/Nestable](https://github.com/dbushell/Nestable)).
And for PHP script reference from ([https://arjunphp.com/nested-menu-categories-single-mysql-query-using-php/](https://arjunphp.com/nested-menu-categories-single-mysql-query-using-php/))

# Demo
([Youtube Here](https://youtu.be/u-zW7G9qzRI))

([Visit Here](https://management-menu.herokuapp.com/))

# Note
Please report me if you found some bug
