<?php if($header) echo $header ;?>
<?php if($left) echo $left ;?>
<?php if($right) echo $right ;?>
<?php if($middle) echo $middle ;?>
<?php if($footer) echo $footer ;?>
