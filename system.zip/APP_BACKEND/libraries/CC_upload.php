<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CC_upload
{
	protected $ci;

	public function __construct()
	{
        $this->ci =& get_instance();
	}

	

}

/* End of file Layout.php */
/* Location: .//C/xampp/htdocs/meeting/project/mainpattern/APP_BACKEND/libraries/Layout.php */
