<?php if($header) echo $header ;?>
<?php if($middle) echo $middle ;?>
<?php if($right) echo $right ;?>
<?php if($footer) echo $footer ;?>
