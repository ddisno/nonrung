<?php
// lang header
$lang['lang_title'] = 'Album - Office of the Municipal Buayai City';
// tab payment
$lang['tab_gallary'] = 'Album';

// readmore
$lang['readmore'] = 'Readmore';
?>