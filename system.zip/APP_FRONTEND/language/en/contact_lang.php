<?php
// lang header
$lang['lang_title'] = 'Contact - SB Dragon';

//contact
$lang['btn_contact'] = 'Send Message';

//header
$lang['header'] = 'Send us an Email';
$lang['name'] = 'NAME';
$lang['email'] = 'EMAIL';
$lang['tel'] = 'PHONE';
$lang['subject'] = 'SUBJECT';
$lang['message'] = 'MESSAGE';
// tab Contact
$lang['tab_contact'] = 'Contact';

//section tab contacts
$lang['contacts_call'] = 'Call us today at';
$lang['contacts_email'] = 'or Email us at';
$lang['contacts_support'] = 'We strive to provide Our Customers with Top Notch Support to make their Theme Experience Wonderful';
?>