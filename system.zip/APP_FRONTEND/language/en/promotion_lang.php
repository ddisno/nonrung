<?php
// lang header
$lang['lang_title'] = 'promotion - SB Dragon';

//contact
$lang['btn_contact'] = 'Contact';

// tab promotion
$lang['tab_promotion'] = 'promotion';

//section tab contacts
$lang['contacts_call'] = 'Call us today at';
$lang['contacts_email'] = 'or Email us at';
$lang['contacts_support'] = 'We strive to provide Our Customers with Top Notch Support to make their Theme Experience Wonderful';
?>