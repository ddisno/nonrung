<?php
// lang header
$lang['lang_title'] = 'Payment - SB Dragon';

//contact
$lang['btn_contact'] = 'Contact';

// tab payment
$lang['tab_payment'] = 'Payment';

//section tab contacts
$lang['contacts_call'] = 'Call us today at';
$lang['contacts_email'] = 'or Email us at';
$lang['contacts_support'] = 'We strive to provide Our Customers with Top Notch Support to make their Theme Experience Wonderful';
?>