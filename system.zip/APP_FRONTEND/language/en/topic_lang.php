<?php
// lang header
$lang['lang_title'] = 'รับเรื่องร้องทุกข์ - สำนักงานเทศบาลเมืองบัวใหญ่';

// tab about
$lang['tab_topic'] = 'รับเรื่องร้องทุกข์';


?>