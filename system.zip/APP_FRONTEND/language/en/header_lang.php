<?php
// menu
$lang['menu_home'] = 'HOME';
$lang['menu_ceo'] = 'CEO';
$lang['menu_comunication'] = 'Public relations';
$lang['menu_politan'] = 'Government service';
$lang['menu_request'] = 'Complaints';
$lang['menu_centernews'] = 'News center';
$lang['menu_contact'] = 'Contacts';
// end menu

// lang change
$lang['lang_change'] = 'English';
$lang['lang_change_th'] = 'Thailand';
$lang['lang_change_en'] = 'English';
// shopping cart
$lang['shopping_cart'] = 'Shopping Cart';
$lang['view_cart'] = 'View Cart';
?>