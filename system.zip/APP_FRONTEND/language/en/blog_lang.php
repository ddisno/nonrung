<?php
// lang header
$lang['lang_title'] = 'News / Activity - Office of the Municipal Buayai City';
$lang['category']  = 'Category';
$lang['cats_all']  = 'All';
// tab payment
$lang['tab_blog'] = 'Products';

// readmore
$lang['readmore'] = 'Readmore';
?>