<?php
// lang header
$lang['lang_title'] = 'Home - Municipal Buayai City';


//contact
$lang['btn_contact'] = 'CONTACT';

// section news
$lang['section_news'] = 'NEWS / ACTIVITY';

// section products
$lang['section_products'] = 'OUR <span>PRODUCTS</span>';
$lang['section_products_sub'] = 'We select and pay attention to the details of production.';

//section tab contacts
$lang['contacts_call'] = 'Call us today at';
$lang['contacts_email'] = 'or Email us at';
$lang['contacts_support'] = 'We strive to provide Our Customers with Top Notch Support to make their Theme Experience Wonderful';


?>