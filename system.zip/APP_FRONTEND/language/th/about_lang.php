<?php
// lang header
$lang['lang_title'] = 'เกี่ยวกับเรา - เอสบีดราก้อน';

//contact
$lang['btn_contact'] = 'ติดต่อเรา';

// tab about
$lang['tab_about'] = 'เกี่ยวกับเรา';

//section tab contacts
$lang['contacts_call'] = 'โทรหาเราวันี้';
$lang['contacts_email'] = 'หรือ อีเมล์เรา';
$lang['contacts_support'] = 'เรามุ่งมั่นที่จะให้การสนับสนุนลูกค้าอย่างดีที่สุดเพื่อสร้างประสบการณ์การใช้งานที่ยอดเยี่ยม';
?>