<?php
// lang header
$lang['lang_title'] = 'ร่วมงานกับเรา - เอสบีดราก้อน';

//contact
$lang['btn_contact'] = 'ติดต่อเรา';

// tab promotion
$lang['tab_career'] = 'ร่วมงานกับเรา';

//section tab contacts
$lang['contacts_call'] = 'โทรหาเราวันี้';
$lang['contacts_email'] = 'หรือ อีเมล์เรา';
$lang['contacts_support'] = 'เรามุ่งมั่นที่จะให้การสนับสนุนลูกค้าอย่างดีที่สุดเพื่อสร้างประสบการณ์การใช้งานที่ยอดเยี่ยม';
?>