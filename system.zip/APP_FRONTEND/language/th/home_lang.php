<?php
// lang header
$lang['lang_title'] = 'หน้าแรก - เทศบาลเมืองบัวใหญ่';


//contact
$lang['btn_contact'] = 'ติดต่อเรา';

// section news
$lang['section_news'] = 'ข่าวสาร / กิจกรรม';

// section products
$lang['section_products'] = '<span>สินค้า</span>ของเรา';
$lang['section_products_sub'] = 'เราเลือกและใส่ใจกับรายละเอียดของการผลิต';

//section tab contacts
$lang['contacts_call'] = 'โทรหาเราวันนี้';
$lang['contacts_email'] = 'หรือ อีเมล์เรา';
$lang['contacts_support'] = 'เรามุ่งมั่นที่จะให้การสนับสนุนลูกค้าอย่างดีที่สุดเพื่อสร้างประสบการณ์การใช้งานที่ยอดเยี่ยม';


?>