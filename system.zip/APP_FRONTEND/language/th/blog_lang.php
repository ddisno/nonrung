<?php
// lang header
$lang['lang_title'] = 'ข่าวสารและกิจกรรม - สำนักงานเทศบาลเมืองบัวใหญ่';
$lang['category']  = 'หมวดหมู่';
$lang['cats_all']  = 'ทั้งหมด';
// tab payment
$lang['tab_blog'] = 'ข่าวสารและกิจกรรม';

// readmore
$lang['readmore'] = 'อ่านต่อ';


?>