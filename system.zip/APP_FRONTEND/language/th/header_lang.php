<?php

// menu
$lang['menu_home'] = 'หน้าแรก';
$lang['menu_ceo'] = 'ผู้บริหาร';
$lang['menu_comunication'] = 'ข่าวประชาสัมพันธ์';
$lang['menu_politan'] = 'ข้อมูลพื้นฐาน';
$lang['menu_request'] = 'รับเรื่องร้องทุกข์';
$lang['menu_centernews'] = 'ศูนย์ข้อมูลข่าวสารฯ';
$lang['menu_contact'] = 'ติดต่อเรา';
// end menu

// lang change
$lang['lang_change'] = 'ไทย';
$lang['lang_change_th'] = 'ไทย';
$lang['lang_change_en'] = 'อังกฤษ';

// shopping cart
$lang['shopping_cart'] = 'รายการสินค้า';
$lang['view_cart'] = 'ดูตะกร้า';
?>