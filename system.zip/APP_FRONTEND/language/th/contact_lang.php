<?php
// lang header
$lang['lang_title'] = 'ติดต่อเรา - สำนักงานเทศบาลเมืองบัวใหญ่';

//contact
$lang['btn_contact'] = 'ส่งข้อความ';

//header
$lang['header'] = 'ส่งอีเมล์ถึงเรา';
$lang['name'] = 'ชื่อ';
$lang['email'] = 'อีเมล์';
$lang['tel'] = 'เบอร์โทรศัพท์';
$lang['subject'] = 'หัวข้อ';
$lang['message'] = 'ข้อความ';
// tab Contact
$lang['tab_contact'] = 'ติดต่อเรา';

//section tab contacts
$lang['contacts_call'] = 'Call us today at';
$lang['contacts_email'] = 'or Email us at';
$lang['contacts_support'] = 'We strive to provide Our Customers with Top Notch Support to make their Theme Experience Wonderful';
?>