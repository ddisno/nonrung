<?php
// lang header
$lang['lang_title'] = 'อัลบั้มรูปภาพ - สำนักงานเทศบาลเมืองบัวใหญ่';
// tab payment
$lang['tab_gallary'] = 'อัลบั้มรูปภาพ';

// readmore
$lang['readmore'] = 'อ่านต่อ';


?>